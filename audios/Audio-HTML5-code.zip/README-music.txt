// Created by: Allwebco Design Corporation - http://allwebcodesign.com


INSTRUCTIONS:

1. Place the "Audio-HTML5.js" in your website folder.

2. Place the .mp3 and .ogg files in your website folder.

3. Add this line to any HTML page you want to add sound to:

<script language="JavaScript" type="text/javascript" src="Audio-HTML5.js"></script>

4. Replace the .mp3 and .ogg files.

5. Edit the "Audio-HTML5.js" to change options.





For help with this add-on please visit the following link:

http://www.allwebco-templates.com/support/S_script_music.htm


